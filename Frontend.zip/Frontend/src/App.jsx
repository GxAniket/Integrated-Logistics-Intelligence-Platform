import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";
import "./App.css";

// =========================================================
// PUBLIC PAGES
// =========================================================

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";

// =========================================================
// CUSTOMER
// =========================================================

import CustomerDashboard from "./pages/dashboards/CustomerDashboard";
import ActiveShipments from "./pages/ActiveShipments";
import ShipmentHistory from "./pages/ShipmentHistory";
import Tracking from "./pages/Tracking";
import Notifications from "./pages/Notifications";
import TrackingInsights from "./pages/TrackingInsights";

// =========================================================
// BUSINESS CLIENT
// =========================================================

import BusinessDashboard from "./pages/dashboards/BusinessDashboard";
import CreateShipment from "./pages/CreateShipment";
import ShipmentManagement from "./pages/ShipmentManagement";
import BusinessShipmentHistory from "./pages/BusinessShipmentHistory";
import PackageInformation from "./pages/PackageInformation";
import BusinessTracking from "./pages/BusinessTracking";
import DeliveryPerformance from "./pages/DeliveryPerformance";
import DelayAnalysis from "./pages/DelayAnalysis";
import LogisticsOverview from "./pages/LogisticsOverview";
import CustomerActivity from "./pages/CustomerActivity";
import Reports from "./pages/Reports";
import BusinessNotifications from "./pages/BusinessNotifications";
import BusinessModule from "./pages/BusinessModule";

// =========================================================
// LOGISTICS OPERATOR
// =========================================================

import OperatorDashboard from "./pages/dashboards/OperatorDashboard";
import OperatorShipmentTracking from "./pages/OperatorShipmentTracking";
import OperatorLiveDelivery from "./pages/OperatorLiveDelivery";
import DriverTracking from "./pages/DriverTracking";
import OperatorRouteManagement from "./pages/OperatorRouteManagement";
import OperatorETADelays from "./pages/OperatorETADelays";
import OperatorProofOfDelivery from "./pages/OperatorProofOfDelivery";

// =========================================================
// SUPPORT AGENT
// =========================================================

import SupportDashboard from "./pages/dashboards/SupportDashboard";

// =========================================================
// ADMINISTRATOR
// =========================================================

import AdminDashboard from "./pages/dashboards/AdminDashboard";

const DASHBOARD_BY_ROLE = {
  CUSTOMER: "/dashboard/customer",
  BUSINESS_CLIENT: "/dashboard/business",
  LOGISTICS_OPERATOR: "/dashboard/operator",
  SUPPORT_AGENT: "/dashboard/support",
  ADMINISTRATOR: "/dashboard/admin",
};

function RequireRole({ role }) {
  const token = localStorage.getItem("shiptrackToken");
  const location = useLocation();
  let user;

  try {
    user = JSON.parse(localStorage.getItem("shiptrackUser") || "null");
  } catch {
    return <Navigate to="/login" replace />;
  }

  if (!token || !user?.role) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (user.role !== role) {
    return <Navigate to={DASHBOARD_BY_ROLE[user.role] || "/login"} replace />;
  }

  return <Outlet />;
}

function App() {
  return (
    <BrowserRouter>

      <Routes>

        {/* =================================================
            PUBLIC ROUTES
        ================================================= */}

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />


        <Route element={<RequireRole role="CUSTOMER" />}>
        {/* =================================================
            CUSTOMER ROUTES
        ================================================= */}

        <Route
          path="/dashboard/customer"
          element={<CustomerDashboard />}
        />

        <Route
          path="/shipments/active"
          element={<ActiveShipments />}
        />

        <Route
          path="/shipments/history"
          element={<ShipmentHistory />}
        />

        <Route
          path="/tracking"
          element={<Tracking />}
        />

        <Route
          path="/notifications"
          element={<Notifications />}
        />

        <Route
          path="/tracking-insights"
          element={<TrackingInsights />}
        />
        </Route>

        <Route element={<RequireRole role="BUSINESS_CLIENT" />}>
        {/* =================================================
            BUSINESS CLIENT ROUTES
        ================================================= */}

        <Route
          path="/dashboard/business"
          element={<BusinessDashboard />}
        />

        <Route
          path="/business/create-shipment"
          element={<CreateShipment />}
        />

        <Route
          path="/business/shipment-management"
          element={<ShipmentManagement />}
        />

        <Route
          path="/business/shipment-history"
          element={<BusinessShipmentHistory />}
        />

        <Route
          path="/business/package-information"
          element={<PackageInformation />}
        />

        <Route
          path="/business/tracking"
          element={<BusinessTracking />}
        />

        <Route
          path="/business/delivery-performance"
          element={<DeliveryPerformance />}
        />

        <Route
          path="/business/delay-analysis"
          element={<DelayAnalysis />}
        />

        <Route
          path="/business/logistics-overview"
          element={<LogisticsOverview />}
        />

        <Route
          path="/business/customer-activity"
          element={<CustomerActivity />}
        />

        <Route
          path="/business/reports"
          element={<Reports />}
        />

        <Route
          path="/business/notifications"
          element={<BusinessNotifications />}
        />

        <Route
          path="/business/module"
          element={<BusinessModule />}
        />
        </Route>

        <Route element={<RequireRole role="LOGISTICS_OPERATOR" />}>
        {/* =================================================
            LOGISTICS OPERATOR ROUTES
        ================================================= */}

        <Route
          path="/dashboard/operator"
          element={<OperatorDashboard />}
        />

        <Route
          path="/operator/shipment-tracking"
          element={<OperatorShipmentTracking />}
        />

        <Route
          path="/operator/live-delivery"
          element={<OperatorLiveDelivery />}
        />

        <Route
          path="/operator/driver-tracking"
          element={<DriverTracking />}
        />

        <Route
          path="/operator/routes"
          element={<OperatorRouteManagement />}
        />

        <Route
          path="/operator/eta-delay"
          element={<OperatorETADelays />}
        />

        <Route
          path="/operator/pod"
          element={<OperatorProofOfDelivery />}
        />
        </Route>

        <Route element={<RequireRole role="SUPPORT_AGENT" />}>
        {/* =================================================
            SUPPORT AGENT ROUTES
        ================================================= */}

        <Route
          path="/dashboard/support"
          element={<SupportDashboard />}
        />

        <Route
          path="/support/shipments"
          element={<SupportDashboard />}
        />

        <Route
          path="/support/tracking"
          element={<SupportDashboard />}
        />

        <Route
          path="/support/notifications"
          element={<SupportDashboard />}
        />

        <Route
          path="/support/reports"
          element={<SupportDashboard />}
        />

        <Route
          path="/support/account"
          element={<SupportDashboard />}
        />
        </Route>

        <Route element={<RequireRole role="ADMINISTRATOR" />}>
        {/* =================================================
            ADMINISTRATOR ROUTES
        ================================================= */}

        <Route
          path="/dashboard/admin"
          element={<AdminDashboard />}
        />
        </Route>


        {/* =================================================
            FALLBACK
        ================================================= */}

        <Route
          path="*"
          element={<Home />}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;